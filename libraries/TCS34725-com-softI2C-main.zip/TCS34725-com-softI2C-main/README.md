# TCS34725-com-softI2C
Emulador de portas I2C a partir de qualquer porta digital do arduino, já com o TCS34725 implementado
